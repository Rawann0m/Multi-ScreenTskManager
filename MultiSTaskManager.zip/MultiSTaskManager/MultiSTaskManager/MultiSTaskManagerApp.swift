//
//  MultiSTaskManagerApp.swift
//  MultiSTaskManager
//
//  Created by Rawan on 11/09/1446 AH.
//

import SwiftUI

@main
struct MultiSTaskManagerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
