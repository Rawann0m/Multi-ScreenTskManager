//
//  TaskModel.swift
//  MultiSTaskManager
//
//  Created by Rawan on 11/09/1446 AH.
//

import SwiftUI
//here is the structure of my tasks
struct Task: Identifiable {
    let id = UUID()
    var title: String
    var isCompleted: Bool
}
