//
//  ContentView.swift
//  MultiSTaskManager
//
//  Created by Rawan on 11/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var taskViewModel = TaskViewModel()
    
    var body: some View {
        NavigationStack {
            VStack {
                // Add Task Navigation Link
                NavigationLink(destination: AddTaskView(taskViewModel: taskViewModel)) {
                    Text("Add Task")
                        .font(.subheadline)
                        .padding()
                        .foregroundColor(.purple)
                    //Dynamic Type size
                        .dynamicTypeSize(.large ... .xxLarge)
                        .accessibilityLabel("Add a new task")
                        .accessibilityHint("Opens the add task screen")
                }
                .padding(5)
                
                // Task List
                List {
                    ForEach(taskViewModel.sortedTasks) { task in
                        HStack {
                            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                                //.accessibilityHidden(true) //i think it is important to be seen by the voiceover
                                .foregroundColor(task.isCompleted ? .green : .gray)
                                .onTapGesture {
                                    taskViewModel.toggleTaskCompletion(task: task)
                                }

                            Text(task.title)
                                .strikethrough(task.isCompleted, color: .gray)
                                .foregroundColor(task.isCompleted ? .gray : .primary)
                                .dynamicTypeSize(.large ... .xxLarge)
                        }
                        .padding()
                    }
                    .onDelete(perform: taskViewModel.deleteTask)
                }.scrollContentBackground(.hidden)
                
                // Dark Mode Toggle
                Toggle("Enable Dark Mode", isOn: $taskViewModel.isDarkMode)
                    .padding()
                    .accessibilityHint("Toggles dark mode for better visibility")
            }
            .background(.gray.opacity(0.1))
            .navigationTitle("To-Do List")
            .preferredColorScheme(taskViewModel.isDarkMode ? .dark : .light)
        }
    }
}

#Preview {
    ContentView()
}
