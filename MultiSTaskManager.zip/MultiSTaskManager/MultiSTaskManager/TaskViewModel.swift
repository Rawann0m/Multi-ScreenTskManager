//
//  TaskViewModel.swift
//  MultiSTaskManager
//
//  Created by Rawan on 11/09/1446 AH.
//
import SwiftUI

class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = [
        Task(title: "Complete project", isCompleted: false),
        Task(title: "Read a book", isCompleted: false),
        Task(title: "Go for a walk", isCompleted: true)
    ]
    
    @Published var isDarkMode = false

    // Add a new task
    func addTask(title: String) {
        withAnimation(.spring()){
            guard !title.isEmpty else { return }
            tasks.append(Task(title: title, isCompleted: false))
        }
    }
    
    // Toggle task completion
    func toggleTaskCompletion(task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()
        }
    }
    
    // Delete task
    func deleteTask(at offsets: IndexSet) {
        withAnimation(.easeInOut) {
            tasks.remove(atOffsets: offsets)
        }
    }
    
    // Sort tasks: Uncompleted tasks first
    var sortedTasks: [Task] {
        tasks.sorted { !$0.isCompleted && $1.isCompleted }
    }
}

