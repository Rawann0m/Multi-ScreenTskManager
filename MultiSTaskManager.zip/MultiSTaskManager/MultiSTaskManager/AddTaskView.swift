//
//  AddTaskView.swift
//  MultiSTaskManager
//
//  Created by Rawan on 11/09/1446 AH.
//


import SwiftUI

struct AddTaskView: View {
    @ObservedObject var taskViewModel: TaskViewModel
    @State private var newTask = ""
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
       
            NavigationView {
                ZStack{
                (Color.gray.opacity(0.1))
                    .edgesIgnoringSafeArea(.all)
                HStack {
                    TextField("Enter new task", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .dynamicTypeSize(.large ... .xxLarge)
                        .accessibilityLabel("New task field")
                        .accessibilityHint("Type the name of the task here")
                    
                    Button(action: addTask) {
                        Image(systemName: "plus")
                            .padding()
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                            .dynamicTypeSize(.large ... .xxLarge)
                            .accessibilityLabel("Confirm add task")
                            .accessibilityHint("Adds the task to the list")
                    }
                    .padding(.trailing)
                }
                .navigationTitle("New Task")
                
            }
        }
    }
    private func addTask() {
        taskViewModel.addTask(title: newTask)
        dismiss()
    }
}
